Hazem Mohamed — Portfolio website
=================================
Open index.html in Chrome to view it (double-click works offline; fonts load when online).

Upload the whole folder (index.html + media + vendor) as-is to any static host:
- Netlify: drag the folder onto app.netlify.com/drop
- Vercel / GitHub Pages / Cloudflare Pages also work.

Edit content: all numbers and texts live in the DATA block inside index.html (search for "DATA").
Replace media: keep the same file names inside /media.
