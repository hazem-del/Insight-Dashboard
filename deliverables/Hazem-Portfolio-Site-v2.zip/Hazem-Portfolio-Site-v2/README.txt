Hazem Mohamed — Portfolio website (v2, built on the Rajib Kabir reference layout)
Open index.html in Chrome to view it. Upload the whole folder (index.html + media + vendor) to Netlify Drop, Vercel or GitHub Pages to publish it.
All texts and numbers live inside index.html (search for WORK, STEPS, NOTES, FAQ and CLIENTS).
