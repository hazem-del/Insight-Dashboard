Hazem Mohamed — Portfolio v4
============================

Open index.html in Chrome, Safari or Edge. It works straight from the folder:
the portrait, the robot twin and its animation are embedded inside index.html.

To put it online (Netlify Drop, Vercel, Hostinger, GitHub Pages…):
upload the whole folder as-is — index.html plus the media/ folder.

What is where
- Hero: animated gradient + fluid reveal (same technique as the reference).
  Move the mouse (or drag a finger) over the portrait: a small liquid patch
  reveals the AI robot twin, grows while you hold still and fades about 2s
  after you move on. The robot's video loop plays only while it is revealed.
- Scrolling: smooth scroll at 1.4s (desktop) with the reference's entrance
  motions; project cards spring in and out as they pass.
- media/hazem-studio.webp  studio retouch of your real photo (hero base)
- media/hazem-robot.webp   robot twin still (same pose, pixel-aligned)
- media/robot-loop.mp4/.webm  robot animation, colour on top half, alpha mask
  on bottom half (read by the WebGL shader)
- media/mark-*.webp        logo mark: your face, swaps to the robot on hover
- Case-study screenshots/videos: dahsha-*, khart-*

To change text: open index.html in any editor and search for the sentence.
Contact number and email are in the "contact" section and the footer.
