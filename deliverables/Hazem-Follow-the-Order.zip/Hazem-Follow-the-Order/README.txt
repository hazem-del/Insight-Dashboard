Hazem Mohamed — "Follow the Order" portfolio
=============================================

A separate site from the cream portfolio (v4). Open index.html in Chrome,
Safari or Edge — it works straight from the folder (animation libraries and
the portrait are embedded). To put it online, upload the whole folder.

The idea
- The page follows one order. Your portrait is made of particles (the
  impressions); scrolling pours them through four funnel stages beside the
  story: Session → Add to cart → Checkout (47% leak out in orange) → Purchase.
- "Meet my AI twin" re-colours the particle portrait into the robot twin.
- A live "Pixel events" panel fires PageView → AddToCart → Purchase as you go.
- Case files scroll sideways; the ten records print on a thermal receipt;
  the five-step method turns on a ring; the contact is a checkout that opens
  WhatsApp with the order filled in.

Fallbacks: without WebGL, or with "reduce motion" on, the page shows the
normal photo and keeps every section readable.
